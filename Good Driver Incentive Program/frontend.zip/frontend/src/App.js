import React, { useState, useEffect } from 'react';

function About() {
  return (
    <div>
	 	<h1>About</h1>
		<p>
		Welcome to the Good Driver Incentive Program! A program dedicated to rewarding drivers for their responsible driving with free products!
		</p>
		<h2>
		Sponsor Features
		</h2>
		<p>
		Sponsors can use this web application to create Sponsor User accounts, accept applications from drivers to join this program, and award or remove points from driver accounts. Drivers can use these points to make purchases from a live catalog curated by the Sponsor.
		</p>
	</div>
  );
}

export default About;
